
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version: str = '1.20.2'
version: str = '1.20.2'
full_version: str = '1.20.2'
git_revision: str = 'b19ad5bfa396a4600a52a598a30a65d4e993f831'
release: bool = True

if not release:
    version = full_version
